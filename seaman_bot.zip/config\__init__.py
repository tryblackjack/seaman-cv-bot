# -*- coding: utf-8 -*-
"""
Модуль конфигурации бота
"""
from .settings import *
